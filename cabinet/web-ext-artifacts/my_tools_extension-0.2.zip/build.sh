npm run build
cp manifest.json dist
cp background.js dist
cp icon.png dist
web-ext build
